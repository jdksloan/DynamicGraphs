
declare @LoanID as varchar(MAX) = '02406285283ae6008de585af2cb14234'

